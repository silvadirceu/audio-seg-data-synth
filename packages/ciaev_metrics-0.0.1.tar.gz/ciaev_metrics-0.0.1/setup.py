# - * - coding: utf - 8 -
from setuptools import setup, find_packages

setup(
    name='ciaev.metrics',
    version="0.0.1",
    description='Audio Cover Song Metrics: A library to compare '
                'results of algorithms of VI',
    packages=['ciaev', 'ciaev.metrics', 'ciaev.metrics.util'],
    install_requires=["pyannote.core==4.3"]
    #package_data={'': ['data/*.csv']}
)