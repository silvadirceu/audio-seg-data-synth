from setuptools import setup, find_packages

setup(
    name='hermes',
    version='0.1',
    packages=find_packages(),
    install_requires=[
        'tritonclient',
        'ovmsclient',
    ],
    # metadata
    author='Innovox',
#    author_email='your@email.com',
    description='Model Server Inference Wrapper',
#    url='https://github.com/yourusername/my_package',
)
