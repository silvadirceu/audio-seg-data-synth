from ovmsclient import make_grpc_client
from numpy import ndarray
from ..abstract.client import Client, Connection


class OpenVinoClient(Client):
    def __init__(self, model_name: str, connection_params: Connection):
        self.client = make_grpc_client(
            f"{connection_params['ip']}:{connection_params['grpc_port']}"
        )
        self.model_name = model_name
        self.metadata = self.client.get_model_metadata(model_name)

    def predict(self, input_data: list[ndarray], timeout: int = None):
        inputs_meta = self.metadata["inputs"]
        inputs = {}

        for i, (k, _) in enumerate(inputs_meta.items()):
            inputs[k] = input_data[i]

        response = self.client.predict(
            inputs=inputs, model_name=self.model_name, timeout=timeout
        )

        if isinstance(response, ndarray):
            for k, _ in inputs_meta.items():
                return {k: response}

        return response
